﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace TX_SituationTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Thread thread1;

        private void LogFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBox1.Text = folderDlg.SelectedPath;
            }
        }

        private void ExcelSheet_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Select a Excel file";
            //fdlg.InitialDirectory = @"D:\";
            fdlg.Filter = "Excel Files (*.xls*)|*.xlsx*|Excel Files (*.xls*)|*.xlsx*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = fdlg.FileName;
            }
        }

        private void FillExcel_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            thread1 = new Thread(() => ResultInExcel_Click(sender, e));
            thread1.Start();
        }

        public void ResultInExcel_Click(object sender, EventArgs e)
        {
            button3.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            xlWorkBook = xlapp.Workbooks.Open(textBox2.Text);
            xlWorkSheet = xlWorkBook.ActiveSheet;

            int test = 3;
            string[] files = Directory.GetFiles(textBox1.Text);
            foreach (string file in files)
            {             
                string name = file.Substring(file.LastIndexOf("\\") + 1);
                if (file.Contains(".log"))
                {
                    int i = 0;
                    List<string> AllLogLines = new List<string>();
                    string[] lines = System.IO.File.ReadAllLines((textBox1.Text + "\\" + name));
                    foreach (string line in lines)
                    {
                        if(line.Contains("Comparing and commenting the signals"))
                        {
                            i = 1;
                        }
                        if(i==1)
                        {
                            String searchString = "Signal:";
                            int startIndex = line.IndexOf(searchString);
                            if (startIndex != -1)
                            {
                                string line1 = line.Substring( (startIndex + 8) , line.Length - (startIndex + 9) );
                                AllLogLines.Add(line1);
                            }                     
                        }
                        if ((line.Contains("Test_Segment") || line.Contains("Test_Step")) && i == 1) 
                        {
                            i = 0;
                            break;
                        }
                    }

                    string TestName = name.Replace(".log", "");
                    xlWorkSheet.Cells[test, 1] = TestName;
                    int x = 2,y = 2;
                    for (var j = 0 ; j < AllLogLines.Count; j++)
                    {
                        string line = AllLogLines[j];

                        string MeasuredValue = line.Substring(line.LastIndexOf(" "));

                        int startIndex = line.IndexOf("EXPECTED");
                        string SignalName = line.Substring( 0 , startIndex - 1);

                        int Index = line.IndexOf("MEASURED");
                        string Temp = line.Substring(0, Index - 2);
                        string ExpectedValue = Temp.Substring(Temp.LastIndexOf(" "));

                        if ( !(ExpectedValue.Equals(MeasuredValue)))
                        {
                            xlWorkSheet.Cells[test, x].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        }

                        xlWorkSheet.Cells[test, x++] = ExpectedValue;
                        xlWorkSheet.Cells[test, x++] = MeasuredValue;

                        if (test == 3)
                        {
                            xlWorkSheet.Cells[1, y] = SignalName;
                            xlWorkSheet.Cells[2, y] = "E";
                            xlWorkSheet.Cells[2, y+1] = "M";
                            y = y + 2;
                        }

                    }
                    test++;
                }
            }
            
            xlWorkBook.Save();
            xlWorkBook.Close();           
            MessageBox.Show("ExcelSheet Updated");
            button3.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = true;
            xlapp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlapp);
        }

    }
}
